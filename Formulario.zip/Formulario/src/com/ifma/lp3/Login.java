package com.ifma.lp3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Login extends JFrame
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton Jbt;
	JButton Jbt2;
	JButton Jbt3;
	JLabel sSays;
	JLabel entr;
	JLabel Hscr;
	JLabel gmrs;
	JTextField	Jtx;
	Integer pts = 0;
	JCheckBoxMenuItem sbar;
	JComboBox  combobox ;
	JPanel sel;
	JPanel labl;
	JTextArea area; 
	
	final String[] authors = {
			"Leo Tolstoy", "John Galsworthy", 
		    "Honore de Balzac", "Stefan Zweig", 
			"Boris Pasternak", "Tom Wolfe"
		    };
	
	public Login()
	{
		
		setLayout(new BorderLayout());
		
		//Titulo
		sSays = new JLabel("Arthur");
		sSays.setFont(new Font("SansSerif",Font.PLAIN, 30));
		
		//Login
		entr = new JLabel("Insira seu nome:");
		Jtx = new JTextField(15);
		Jbt = new JButton("Login");
		
		//Criar novo usuario
		Jbt2 = new JButton("Criar novo Usuario");
		Hscr = new JLabel("Pontos: "+pts);
		sbar = new JCheckBoxMenuItem("Check");
		gmrs = new JLabel("Jogadores");
		combobox = new JComboBox(authors);
		
		labl = new JPanel(new FlowLayout());
		area = new JTextArea(10,15); 
		area.setLineWrap(true);
        area.setWrapStyleWord(true);
        area.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
		sel	= new JPanel(new FlowLayout(FlowLayout.CENTER, 200, 30));
		
		labl.setBackground(Color.WHITE);
		sel.setBackground(Color.lightGray);
		
		labl.add(sSays);

		sel.add(entr);
		sel.add(Jtx);
		sel.add(Jbt);
		
		sel.add(Hscr);
		sel.add(sbar);
		sel.add(gmrs);
		sel.add(combobox);
		sel.add(area);
		Jbt.setBackground(Color.orange);
		sel.add(Jbt2);
		Jbt2.setBackground(Color.orange);
		add(labl,BorderLayout.NORTH);
		
		add(sel,BorderLayout.CENTER);
		
		setSize(400,740);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
		
		
		Jbt.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				if(Jtx.getText().isEmpty()){
					JOptionPane.showMessageDialog(null, "Nenhum usuario informado");
				}else{
					JOptionPane.showMessageDialog(null, "Voc� logou como: " + Jtx.getText());
				}
				
			}
		});
		
		sbar.addItemListener(new ItemListener() {
		      public void itemStateChanged(ItemEvent e) {
		    	  pts++;
		    	  Hscr.setText("Pontos: "+pts);
		    	  System.out.println("Checado ? " + sbar.isSelected());
		      }
		});
		
		combobox.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                JComboBox comboBox = (JComboBox) event.getSource();

                Object selected = comboBox.getSelectedItem();
                System.out.println("Usu�rio selecionado: " + selected);
            }
		});
		
		Jbt2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				JOptionPane.showMessageDialog(null, "Novo usu�rio adicionado " + Jtx.getText());				
				combobox.addItem(area.getText().trim());
				area.setText("");
			}
		});
	}

	public static void main(String[] args)
	{		new Login();	}

}